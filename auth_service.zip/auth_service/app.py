from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager,create_access_token
from werkzeug.security import generate_password_hash,check_password_hash
from models import User
from database import db_session
import os
from dotenv import load_dotenv


load_dotenv()

app = Flask(__name__)

app.config['JWT_SECRET_KEY'] = os.getenv('SECRET_KEY')

jwt = JWTManager(app)


@app.route('/auth/register', methods=['POST'])
def register():
    try:
       data = request.get_json()
       username = data.get('username')
       password = data.get('password')

       hashed_password = generate_password_hash(password)

       user = User(username=username,password=hashed_password)
    

       db_session.add(user)
       db_session.commit()

       return jsonify({"message": "User registered successfully"}),201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/auth/login', methods=['POST'])
def login():
    try:
       data = request.get_json()
       username = data.get('username')
       password = data.get('password')

       user = db_session.query(User).filter_by(username=username).first()

       if user and check_password_hash(user.password,password):
          access_token = create_access_token(identity={'username': user.username})
          return jsonify(access_token=access_token),200
       else:
          return jsonify({"error":"Invalid informations"}),401
    except Exception as e:
        return jsonify({"error":str(e)}),500
    

if __name__ == '__main__':
    app.run(debug=True,port=5000)


